﻿using Microsoft.EntityFrameworkCore;
using Web_Testing.Models.Entities;

namespace Web_Testing.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options) 
        { 
            
        }

        public DbSet<Employee> Employees { get; set; }
    }
}
