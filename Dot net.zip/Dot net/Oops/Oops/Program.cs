﻿// See https://aka.ms/new-console-template for more information
using System;

//public class MyClass
//{
//    static MyClass()
//    {
//        Console.WriteLine("Static Constructor is ran");
//    }

//    public static void printFirst()
//    {
//        Console.WriteLine("First Time");
//    }
//    public static void printSecond()
//    {
//        Console.WriteLine("Second Time");
//    }

//    static void Main(String[] args)
//    {
//        MyClass.printFirst();
//    }

//}

public class Emp
{
    public int id;
    public string Name;

    public Emp(int id, string Name)
    {
        this.id = id;
        this.Name = Name;
    }
}

public class Program
{
    static void Main(string[] args)
    {
        Emp emp = new Emp(001, "Sachin");
        Console.WriteLine(emp.Name);
        Console.ReadLine();
    }
}
